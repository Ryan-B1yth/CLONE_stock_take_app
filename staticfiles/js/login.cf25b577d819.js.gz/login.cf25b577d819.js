
usernameInput = document.getElementById('id_username');
usernameInput.setAttribute('placeholder', 'Username');

passwordInput = document.getElementById('id_password');
passwordInput.setAttribute('placeholder', 'Password');