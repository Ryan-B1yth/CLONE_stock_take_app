
let errors = document.getElementsByClassName('errorlist');

for (let i = 0; i < 2; i++) {

    errors[i].style.backgroundColor = 'hsla(0, 58%, 86%, var(--hover))';
    errors[i].style.width = 'max-content';
    errors[i].style.textAlign = 'center';
    errors[i].style.margin = '5px auto';
    errors[i].style.padding = '10px';
    errors[i].style.borderRadius = '5px';
};
