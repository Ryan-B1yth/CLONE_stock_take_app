let addedPart = document.getElementById('added-part');

if (addedPart.innerText == "") {
    addedProduct = document.getElementById('added-product');
    addedProduct.style.display = 'none';
}