document.getElementById('id_password').remove();
document.getElementsByClassName('helptext')[0].remove();
document.getElementsByTagName('label')[4].remove();